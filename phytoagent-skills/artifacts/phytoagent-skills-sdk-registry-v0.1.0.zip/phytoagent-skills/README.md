# PhytoSkill-Spark · Skill SDK + Registry

第一轮可运行交付：Skill 契约、包完整性验证、Ed25519 签名、Registry 发现与 StepFun function tools 导出。
工程位于 `D:\DRX SPARK\phytoagent-skills`。四个植物领域 Skill、StepFun Harness 和 DGX Spark 部署属于后续轮次。

## 直接运行

需要 Python 3.11+。在 PowerShell 中执行：

```powershell
Set-Location 'D:\DRX SPARK\phytoagent-skills'
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e '.[test]'
.\.venv\Scripts\python.exe -m demo.run_registry_demo --output artifacts/registry-demo.json
.\.venv\Scripts\python.exe -m pytest -q
```

若现有 Python 已有 `jsonschema`、`cryptography`、`PyYAML`、`pytest`，可直接运行：

```powershell
python -m demo.run_registry_demo --output artifacts/registry-demo.json
python -m pytest -q
```

Demo 在临时目录中复制随工程提供的 `contract_probe`，生成临时开发密钥，签名后发现包，导出 Tool Schema，再通过 BaseSkill 执行合成样例。结束后清理临时目录。报告明确包含：

```json
{
  "scope": "sdk_registry_only",
  "mode": "fixture",
  "model_called": false,
  "result": {
    "status": "success",
    "mode": "fixture",
    "echo": "SDK + Registry contract verified",
    "data_origin": "synthetic_fixture"
  }
}
```

这个样例证明 SDK/Registry 的执行闭环；没有调用 StepFun、视觉模型或 RAG。

## 当前结构

```text
phytoagent-skills/
├── sdk/                      BaseSkill、JSON Schema、Manifest、公共异常
├── registry/                 发现、签名验证、tools 导出、CLI、默认配置
├── examples/
│   ├── contract_probe/       可执行的合成契约样例及已封包 manifest
│   └── contract_probe.metadata.json
├── skills/                   植物领域 Skill 的后续安装位置，当前为空
├── demo/run_registry_demo.py 离线签名与契约执行演示
├── tests/                    契约、发现、篡改、签名和 CLI 测试
├── docs/plans/               分轮交付范围
└── pyproject.toml
```

```mermaid
flowchart LR
  Package[SKILL.md + Python + schemas] --> Manifest[Manifest 文件清单与哈希]
  Manifest --> Signature[发布者 Ed25519 签名]
  Key[包外固定公钥] --> Registry[Registry 验证与发现]
  Signature --> Registry
  Registry --> Tools[从输入 Schema 生成 function tools]
  Registry --> Contract[按需读取说明和输入输出契约]
  Contract --> Execute[BaseSkill.execute 契约执行]
  Tools -. 下一轮接入 .-> StepFun[StepFun Harness]
```

## 发布、验证和发现

下面使用示例包演示真实命令。密钥生成命令拒绝覆盖已有文件，第二次运行时保留已有密钥即可。

```powershell
python -m registry keygen --private-key .trust/publisher.private.pem --public-key .trust/publisher.public.pem
python -m registry seal examples/contract_probe --metadata examples/contract_probe.metadata.json
python -m registry sign examples/contract_probe --private-key .trust/publisher.private.pem
python -m registry verify examples/contract_probe --public-key .trust/publisher.public.pem
python -m registry tools --skills-dir examples --public-key .trust/publisher.public.pem
```

`seal` 是发布者主动更新清单的操作。消费端的 `verify`、`discover`、`execute` 均不会自动重新封包。
文件、说明、Schema 或元数据改变后，原有签名不能继续使用；重新计算哈希也不能绕过旧签名。

`registry/registry.json` 默认扫描 `skills/`，要求签名，并从 `.trust/publisher.public.pem` 读取固定公钥。
配置中的相对路径以配置文件目录为基准。当前没有安装领域 Skill，因此没有预填注册条目。

开发时可显式使用 `--allow-unsigned`，此时结果中的签名状态为 `not_checked`。它不会显示为签名通过。
配置使用 `--config`；指定 `--skills-dir` 时才能通过命令行设置信任策略。

```python
from registry import SkillRegistry

registry = SkillRegistry("examples", trusted_public_key=".trust/publisher.public.pem")
registry.discover()  # 原子替换目录快照；失败不发布部分结果
tools = registry.available_tools
instructions = registry.instructions("contract_probe")
registry.validate_input("contract_probe", {"message": "hello"})
```

Registry 发现阶段只读取包元数据，不导入 `skill.py`。`available_tools` 是发现时的快照；执行前应调用
`verify_entry` 检查包是否仍与发现时一致。`instructions` 和 Registry 的输入输出校验已内置这一步。

## 新 Skill 的最小接口

每个包至少包含 `SKILL.md`、`skill.py`、`schema.json`、`manifest.json`；签名发布增加 `manifest.sig`。
函数及目录名使用 `plant_vision` 这种下划线命名，`SKILL.md` frontmatter 使用对应的 `plant-vision`。
`schema.json` 分别提供 `input` 和 `output` 对象，Manifest 用 `schema.json#/input` 和 `schema.json#/output` 引用。

```python
from sdk import BaseSkill

class ContractProbeSkill(BaseSkill):
    def run(self, payload: dict, *, mode: str) -> dict:
        return {
            "status": "success", "mode": mode,
            "echo": payload["message"], "data_origin": "synthetic_fixture",
        }

skill = ContractProbeSkill("examples/contract_probe")
result = skill.execute({"message": "hello"}, mode="fixture")
```

`execute` 依次校验包、模式、输入、运行结果。`run` 收到输入的副本。`validate_input` 和
`validate_output` 也可独立使用。未声明的 `live` / `replay` 模式会报错，不会悄悄返回 fixture。
SDK 没有统一吞掉适配器异常；后续 Harness 将负责结构化失败、超时和降级处理。

Schema 使用 JSON Schema Draft 2020-12，仅允许本地 JSON Pointer `$ref`，禁止远端 Schema、`$id`
及 `$dynamicRef`。拒绝重复 JSON 键、非有限数字、越界资源路径和链接资源。输入输出根类型必须是对象。
支持的约束并不代表 StepFun 服务接受所有 JSON Schema 关键字；本轮验证了 function tools 结构和契约一致性，真实 API 兼容性待联调。

## 验证结果的含义

| 状态 | 当前实现 |
| --- | --- |
| Cataloged | Registry 扫描并注册通过校验的包 |
| Integrity | SHA-256 覆盖代码、Schema、说明和资源；发现新增、缺失、修改 |
| Signed | 外部固定 Ed25519 公钥验证签名；包内自带公钥不能成为信任来源 |
| Documented | 校验 SKILL.md frontmatter 和正文，按需读取 |
| Scanned | `not_checked`，尚未实现代码安全扫描器 |
| Evaluated | `not_checked`，尚未实现植物能力基准评测门禁 |

这些是项目内的验证状态，不表示 NVIDIA 官方认证。框架测试通过也不等于植物诊断效果通过评测。
签名证明来源与完整性，不证明代码安全或结论正确。BaseSkill 自身只检查完整性，发布者信任由 Registry 管理。
Python 执行没有沙箱隔离；当前消费端假定包目录在校验与使用期间不被并发写入。多用户生产运行需要后续执行隔离和只读包存储。
`__pycache__`、`.pyc` / `.pyo` 不在资源清单内；未来执行器应使用已验证源码，避免执行未覆盖的字节码。
开发私钥为未加密 PEM，放在包外 `.trust/` 中，不应随源码包发布。

## 后续接入边界

1. **四个 Skill**：分别实现 `plant_vision`、`growth_risk`、`herbal_knowledge`、`evidence_fusion`，每个包有独立契约和 fixture。
2. **StepFun**：Harness 将 tools 传给真实 API，保留 `tool_call_id`，校验 arguments，执行后提交 JSON tool 消息。StepFun 是唯一任务规划与最终自然语言生成模型。
3. **YOLO / TCM-Mind-RAG**：在对应 Skill 的 `live` 适配器内接入本地权重与检索接口；保留同一输入输出契约，缺少配置时明确失败。
4. **DGX Spark**：复制工程并安装 ARM64 可用依赖，挂载本地权重、向量库和语料，再验证 GPU 推理。`runtime: local_dgx` 只是部署目标声明，不是实机执行证明。

当前轮次不需要 API Key 或 GPU。后续真实接入时需要模型权重路径、TCM-Mind-RAG 项目或接口信息，以及 DGX Spark 连接方式。
若 StepFun 使用云 API，系统仍包含云端调用；全部本地部署需要可用的 StepFun 本地权重和实机验证。
